﻿import * as application from 'tns-core-modules/application';
application.run({ moduleName: "app-root" });
