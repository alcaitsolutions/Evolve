# Example for using nativescript-geolocation plugin
## This example demonstrates how to use plugin with angular

If you want to test it out on an emulator or a device you can follow the instructions below:

* `git clone https://github.com/NativeScript/nativescript-geolocation.git`
* `cd nativescript-geolocation/demo-angular`
* `npm run build.plugin && npm install`
* `tns run android` or `tns run ios` depending on the platform you want to test